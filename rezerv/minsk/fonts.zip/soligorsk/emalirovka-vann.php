<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head><title>Эмалировка ванн в Минске и Минской области.</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<meta name='yandex-verification' content='5022f51f58fdd2c2' />
<meta name="description" content="Эмалировка ванн, наливная ванна,акриловый вкладыш. Профессиональная реставрация ванн в Минске и Минской области " />
<meta name="keywords" content="эмалировка ванн, наливная ванна, акриловый вкладыш, реставрация ванн, покраска ванн, жидкий акрил, стакрил, восстановление ванн, эмалировка ванны в минске и минской области" />
<meta name="Robots" content="index,follow" />
<link href="style_V.css" type="text/css" rel="stylesheet" />
<link href="favicon.ico" rel="shortcut icon" type="image/x-icon" />
</head><body>
<div id="wrapper">

<div id="header"><?php include "Incl/Header.php";?></div>
<div id="flashContent"><?php include "Incl/FlashContent.php";?></div>
<div id="polo_img"></div>
<div id="sidebar"><?php include "Incl/Menu.php";?></div>

<div id="content" style="height:700px;">
<h2 class="zaglv">Эмалировка ванн</h2>
<p><strong>Эмалировка ванн</strong> – это самый первый и дешевый способ реставрации ванн. В соответствии с технологией эмаль финского производства наносится на поверхность ванны кисточкой в два слоя.</p> 
<p>Эмалировка ванн – это способ, который идеально подходит для тех, кто снимает, сдает или продает квартиру.</p>
<p>Покрытие после эмалировки имеет приятный белый глянцевый блеск. Вы сами можете выбрать любой цвет покрытия.</p>
<p>Все работы по реставрации ванны займут от 2-ух до 3-х часов Вашего времени, в зависимости от состояния ванны. Покрытие производится высококачественным финским материалом.</p>
<p>Работа производится на дому, без демонтажа самой ванны, без выноса стиральной машины и без разрушения плитки. Пользоваться новой ванной можно уже через 1-4 дня (в зависимости от выбранных компонентов) после покраски.</p>
<p class="otstup">После эмалировки ваша ванна:</p>
<p>- Прослужит Вам в среднем от 2 до 5 лет;</p>
<p>- Будет иметь красивый блестящий вид;</p>
<p>- Радовать Вас своим блеском и красотой;</p>
<p class="otstup">Гарантия на покрытие 1 год.</p>
</div>
<?php include "Incl/EmalNalivTables.php";?>
<?php include "Incl/Footer.php";?>
</div></body></html>