<ul id="spisok">
<li><a href="http://vanna-lux.by">Главная</a></li>
<li><a href="http://vanna-lux.by/emalirovka-vann.php">Эмалировка ванн</a></li>
<li><a href="http://vanna-lux.by/nalivnaja-vanna.php">Наливная ванна</a></li>
<li><a href="http://vanna-lux.by/acrilovij-vkladish.php">Акриловый вкладыш</a></li>
<li><a href="http://vanna-lux.by/choice.php">Что же выбрать?</a></li>
<li><a href="http://vanna-lux.by/stoimost.php">Стоимость услуг</a></li>
<li><a href="http://vanna-lux.by/uhod-za-vannoj.php">Уход за ванной</a></li>
<li><a href="http://vanna-lux.by/poleznoe.php">Полезно почитать</a></li>
<li><a href="http://vanna-lux.by/contacts.php">Контакты</a></li>
</ul>