<a href="http://vanna-lux.by" title="vanna-lux.by: Реставрация ванн в Минске: эмалировка ванн, наливная ванна, акриловый вкладыш в Минске и Минской области.">
<img src="images/logo.png" id="logo" width="110" height="70" alt="vanna-lux.by" />
<div id="logotext">
<h2 class="lgtextbig">Vanna-lux</h2>
<p class="lgtextsmall">Реставрация ванн</p>
</div></a>
<div id="cont_main_phone">
	<table id="phonetable">
		<tr>
			<td class="velcom"><img src="images/velcom.png"></td>
			<td class="phonevelcom">+375 (29) 305-45-02</td>
		</tr>
		<tr>
			<td class="mtc trHeight"><img src="images/mtc.png"></td>
			<td class="phonemtc trHeight">+375 (29) 562-92-52</td>
		</tr>
		<tr>
			<td colspan="2" class="timework">ежедневно с 8.00 до 22.00</td>
		</tr>
	</table>
</div>