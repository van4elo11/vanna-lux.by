<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head><title>Реставрация ванн в Минске и Минской области. Эмалировка ванн, наливная ванна, акриловый вкладыш.</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<meta name='yandex-verification' content='5022f51f58fdd2c2' />
<meta name="description" content="Как не попасть в просак" />
<meta name="keywords" content="Как не попасть в просак" />
<meta name="Robots" content="index,follow" />
<link href="style_V.css" type="text/css" rel="stylesheet" />
<link href="favicon.ico" rel="shortcut icon" type="image/x-icon" />
</head><body>
<div id="wrapper">

<div id="header"><?php include "Incl/Header.php";?></div>
<div id="flashContent"><?php include "Incl/FlashContent.php";?></div>
<div id="polo_img"></div>
<div id="sidebar"><?php include "Incl/Menu.php";?></div>

<div id="content" style="height:700px;">
<span id="hlebkr"><a href="http://vanna-lux.by/poleznoe.php">Полезно почитать</a>-></span>
<ul>
<li><a href="http://vanna-lux.by/emalirovka-vann-obman.php" title="Реставрация ванн: эмалировка ванн, наливная ванна. Как не попасть впросак?">Эмалировка ванн. Как не попасть впросак?</a></li>
</ul>
</div>
<?php include "Incl/EmalNalivTables.php";?>
<?php include "Incl/Footer.php";?>
</div></body></html>