<div id="emaldiv"><table id="emalTable"><tr><th colspan="2"><a href="http://vanna-lux.by/emalirovka-vann.php">ЭМАЛИРОВКА ВАНН В МИНСКЕ</a></th></tr>
<tr><td>1,5 м</td><td>1,7 м</td></tr><tr><td>от 550 000</td><td>от 600 000</td></tr></table></div>
<div id="nalivdiv"><table id="nalivTable"><tr><th colspan="2"><a href="http://vanna-lux.by/nalivnaja-vanna.php">НАЛИВНАЯ ВАННА ИЗ ЖИДКОГО АКРИЛА ИЛИ СТАКРИЛА В МИНСКЕ</a></th></tr>
<tr><td>1,5 м</td><td>1,7 м</td></tr><tr><td>от 800 000</td><td>от 900 000</td></tr></table></div>