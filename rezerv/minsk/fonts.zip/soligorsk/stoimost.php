<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head><title>Эмалировка ванн, наливная ванна, акриловый вкладыш.</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<meta name='yandex-verification' content='5022f51f58fdd2c2' />
<meta name="description" content="Стоимость оказания услуг по реставрации ванн в Минске. Эмалировка ванн в Минске, наливная ванна в Минске,акриловый вкладыш в Минске и Минской области." />
<meta name="keywords" content="эмалировка ванн, стоимость, цена,стоимость услуги, наливная ванна, акриловый вкладыш, реставрация ванн, покраска ванн, жидкий акрил, стакрил, восстановление ванн в минске и минской области" />
<meta name="Robots" content="index,follow" />
<link href="style_V.css" type="text/css" rel="stylesheet" />
<link href="favicon.ico" rel="shortcut icon" type="image/x-icon" />
</head><body>
<div id="wrapper">
<div id="header"><?php include "Incl/Header.php";?></div>
<div id="flashContent"><?php include "Incl/FlashContent.php";?></div>
<div id="polo_img"></div>
<div id="sidebar"><?php include "Incl/Menu.php";?></div>
<div id="content" style="height:700px;">
<p><strong>Реставрация ванн в Минске и Минской области: эмалировка ванн, наливная ванна, акриловый вкладыш.</strong></p>
<p style="margin-top:20px;font-size:14px;"><strong>Профессиональное восстановление эмалевого покрытия ванны в Минске, Дзержинске, Фаниполе, Солигорске, Слуцке, Копыле, Борисове, Жодино, Узде, Мяделе, Нарочи и многих других городах Минской области.</strong></p>
<br/><p><strong>Стоимость  услуг (в зависимости от применяемого материала):</strong></p>
<div id="cenawrap" style="margin-top:25px;">
<table id="cena" style="width:530px;"> 
<tr><th style="width:200px;">Вид работы</th><th style="width:50px;">Размер ванны</th><th style="width:40px;">Стоимость</th></tr>
<tr><td class="tdcena"><a href="http://vanna-lux.by/emalirovka-vann.php">Эмалировка ванн</a></td><td>1,2</td><td>550 000</td></tr>
<tr><td class="tdcena"><a href="http://vanna-lux.by/emalirovka-vann.php">Эмалировка ванн</a></td><td>1,5</td><td>от 550 000</td></tr>
<tr><td class="tdcena"><a href="http://vanna-lux.by/emalirovka-vann.php">Эмалировка ванн</a></td><td>1,7</td><td>от 600 000</td></tr>
<tr><td class="tdcena"><a href="http://vanna-lux.by/nalivnaja-vanna.php">Наливная ванна</a></td><td>1,2</td><td>800 000</td></tr>
<tr><td class="tdcena"><a href="http://vanna-lux.by/nalivnaja-vanna.php">Наливная ванна</a></td><td>1,5</td><td>от 800 000</td></tr>
<tr><td class="tdcena"><a href="http://vanna-lux.by/nalivnaja-vanna.php">Наливная ванна</a></td><td>1,7</td><td>от 900 000</td></tr>
<tr><td class="tdcena"><a href="http://vanna-lux.by/acrilovij-vkladish.php">Акриловый вкладыш (вставка)</a></td><td>1,5</td><td>2 300 000</td></tr>
<tr><td class="tdcena"><a href="http://vanna-lux.by/acrilovij-vkladish.php">Акриловый вкладыш (вставка)</a></td><td>1,7</td><td>3 300 000</td></tr>
<tr><td colspan="2">если раньше была эмалировка</td><td>180 000</td></tr><tr><td colspan="2">Установка нового сифона</td><td>350 000</td></tr></table>
<br/><p>Цены действительны для города Минска. Стоимость реставрации ванны в Вашем городе уточняйте по телефону.</p>
</div></div><?php include "Incl/Footer.php";?></div></body></html>