window.onload=function(){
	document.getElementById("createOtzive").onclick=addOtzive; //Подписка на событие на надпись добавить отзыв
}

//Для фотогаллереи
var count=1;
var id_imgBox="imgBox";
var VImg="zagluchkaImg";
var VC="VideoComent";
var id_video="vid";
	
function getImgBlock(status){
	if(status == 'true') nextImgBlock();		
	else  prevImgBlock();
}	
function hideImgBox(){
	var BoxNow=id_imgBox+count;  
	var imgBoxNow=document.getElementById(BoxNow);
	imgBoxNow.style.display="none"; 
	closeVideo();
}
function displayImgBox(){
	var BoxNext=id_imgBox+count;
	var imgBoxNext=document.getElementById(BoxNext);
	imgBoxNext.style.display="block";
}
function nextImgBlock(){
	hideImgBox();
	if(count >= 3) count=0;
	count++;				
	displayImgBox();
}
function prevImgBlock(){
	hideImgBox();
	if(count <= 1) count=4;
	count--;
	displayImgBox();
}
function openVideo(){
	var zagluchkaloc=VImg+count;  //Ссылка на изображение заглушку
	var VCloc=VC+count;		//Ссылка на див блок с видео
	var vidloc=id_video+count; // Ссылка на само видео
	
	var hrefVid=document.getElementById(vidloc);
	document.getElementById(zagluchkaloc).style.display="none";
	document.getElementById(VCloc).style.display="block";
	
	switch(vidloc){
		case 'vid1': hrefVid.setAttribute('src',"https://www.youtube.com/embed/0mroGU9Tij4?rel=0");break;
		case 'vid2': hrefVid.setAttribute('src',"https://www.youtube.com/embed/tMLgGfumk58?rel=0");break;
		case 'vid3': hrefVid.setAttribute('src',"https://www.youtube.com/embed/PaYIMtOE00w?rel=0");break;
		default: hrefVid.setAttribute('src',"https://www.youtube.com/embed/ez6EG0cDpPk?rel=0");
	}
}
function closeVideo(){
	var zagluchkaloc=VImg+count;
	var VideoDiv=VC+count;
	var vidloc=id_video+count; // Ссылка на само видео
	document.getElementById(vidloc).setAttribute('src','');
	document.getElementById(VideoDiv).style.display="none";
	document.getElementById(zagluchkaloc).style.display="block";
}

//Открыть видео отзывы


function openVideoOtzive(number){
	var zatichkaImg='zagluchkaImgOtzive'+number;
	var VideoOtz='VideoOtz'+number;
	var OtzVideoBox='OtzVideoBox'+number;
	
	var hrefVideo=document.getElementById(VideoOtz);
	
	document.getElementById(zatichkaImg).style.display="none";
	document.getElementById(OtzVideoBox).style.display="block";
	
	switch(number){
		case '1': hrefVideo.setAttribute('src',"https://www.youtube.com/embed/viPvON9pO6c?rel=0");break;
		case '2': hrefVideo.setAttribute('src',"https://www.youtube.com/embed/2k9vf1jKyo0?rel=0");break;
		case '3': hrefVideo.setAttribute('src',"https://www.youtube.com/embed/b-7Yqnh-kic?rel=0");break;
		case '4': hrefVideo.setAttribute('src',"https://www.youtube.com/embed/Oxqz-zuYKtY?rel=0");break;
		default: hrefVideo.setAttribute('src',"https://www.youtube.com/embed/ez6EG0cDpPk?rel=0");
	}
}

//Текстовые отзывы
var index=1;var id="otziv";
function getOtziv(status){if(status == 'true') nextOtzive(); else prevOtzive();}
function hide(){var idNow=id+index;document.getElementById(idNow).style.display="none";}
function display(){var idNext=id+index;var otzNext=document.getElementById(idNext);otzNext.style.display="block";otzNext.style.margin="200px 0 0 58px";}
function nextOtzive(){hide();if(index >= 9) index=0;index++;display();}	
function prevOtzive(){hide();if(index <= 1)	index=10;index--;display();}
		
//Добавить отзыв с модальными окнами		
function addOtzive(){document.getElementById('OtzBox').style.display='block';document.getElementById("closeAddOtzive").onclick=closeaddOtzive;var shadow=document.getElementById('Otzshadow');shadow.style.display='block';shadow.onclick=closeaddOtzive;hiddenFixedMenu();}
function closeaddOtzive(){document.getElementById('Otzshadow').style.display='';document.getElementById('OtzBox').style.display='';visibleFixedMenu();}
function openThanks(){closeaddOtzive();var shadow=document.getElementById('thxShadow');document.getElementById('wrappthxBox').style.display='block';document.getElementById('closeth').onclick=closeThanks;shadow.style.display='block';shadow.onclick=closeThanks;hiddenFixedMenu();}
function closeThanks(){document.getElementById('wrappthxBox').style.display='';visibleFixedMenu();}

function hiddenFixedMenu(){document.getElementById("wrappMenu").style.display='none';}
function visibleFixedMenu(){document.getElementById("wrappMenu").style.display='block';}

// Скрипт для отправки отзыва
function getXmlHttpRequest(){if (window.XMLHttpRequest){try{return new XMLHttpRequest();}catch (e){}}else if (window.ActiveXObject){try{return new ActiveXObject('Msxml2.XMLHTTP');}catch (e){}try{return new ActiveXObject('Microsoft.XMLHTTP');}catch (e){}}return null;}
function submitOtzive(){var username=document.getElementById('username');var city=document.getElementById('city');var textOtz=document.getElementById('textOtz');if(textOtz.value==''){textOtz.placeholder="Вы не оставили отзыв!";return;}if(username.value==''){username.placeholder="Введите Ваше имя!";return;}var searchString="username="+username.value+"&"+"city="+city.value+"&"+"textOtz="+textOtz.value;var req = getXmlHttpRequest();req.open("POST", "action.php", true);req.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");req.setRequestHeader("Content-Length", searchString.length);req.send(searchString);req.onreadystatechange = function(){if (req.readyState == 4){if (req.status == 200){username.value="";city.value="";textOtz.value="";username.placeholder="Ваше имя";textOtz.placeholder="Ваш отзыв";openThanks();}}}}	

//Скрипт для увеличения из маленькой фотки в большую 
function onPhotoClick(img){var photo=document.getElementById('BigPhoto');var shadow=document.getElementById('Sertshadow');document.getElementById('SertContainerImg').style.display='block';shadow.style.display='block';var bigFotoUrl=img.src.slice(0,-5);bigFotoUrl+="2.jpg";photo.style.background='url("'+bigFotoUrl+'") 50% 50% no-repeat';photo.onclick=closePhoto;shadow.onclick=closePhoto;hiddenFixedMenu();}
function closePhoto(){document.getElementById('SertContainerImg').style.display='';visibleFixedMenu();}
	
// Скрипт для Отправки Заказа из контейнеров Цены 
var typeOrder='';
function openModalBoxOrder(order){var shadow=document.getElementById('Ordershadow');typeOrder=order;shadow.style.display='block';document.getElementById('OrderBoxCeni').style.display='block';shadow.onclick=closeModalBoxOrder;document.getElementById("closeModal").onclick=closeModalBoxOrder;hiddenFixedMenu();}
function closeModalBoxOrder(){document.getElementById('Ordershadow').style.display='';document.getElementById('OrderBoxCeni').style.display='';visibleFixedMenu();}
function openThanksforOrder(){closeModalBoxOrder();var shadow=document.getElementById('ShadowThanksOrder');document.getElementById('ContThanksOrder').style.display='block';document.getElementById('closeImg').onclick=closeThanksforOrder;shadow.style.display='block';shadow.onclick=closeThanksforOrder;hiddenFixedMenu();}
function closeThanksforOrder(){document.getElementById('ContThanksOrder').style.display='';visibleFixedMenu();}
function submitOrder(){var username=document.getElementById('usernameOrder');var phone=document.getElementById('phone');var cityOrder=document.getElementById('cityOrder');if(phone.value==''){phone.placeholder="Введите Ваш номер телефона!";return;}var searchString="usernameOrder="+username.value+"&"+"cityOrder="+cityOrder.value+"&"+"phone="+phone.value+"&"+"typeOrder="+typeOrder;var req = getXmlHttpRequest();req.open("POST", "action.php", true);req.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");req.setRequestHeader("Content-Length", searchString.length);req.send(searchString);req.onreadystatechange = function(){if (req.readyState == 4){if (req.status == 200){username.value="";phone.value="";cityOrder.value="";username.placeholder="Ваше имя";cityOrder.placeholder="Ваш город";phone.placeholder="Ваш телефон";openThanksforOrder();}}}}
