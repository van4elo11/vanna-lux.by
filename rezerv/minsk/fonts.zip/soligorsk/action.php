<?php

	function MyText($T) 
  {
  	$temp=$T;
  	$temp=trim($temp);
  	$temp=stripcslashes($temp);
  	$temp=htmlspecialchars($temp,ENT_QUOTES);
  	
  	return $temp;
  }
  
	// получаем переменные из формы
  $Name=isset($_POST['username']) ? $_POST['username']:'';
  $Email=isset($_POST['email']) ? $_POST['email']:'';
  $Tema=isset($_POST['tema']) ? $_POST['tema']:'';
  $Msg=isset($_POST['msg']) ? $_POST['msg']:'';
  
  
  $Name=MyText($Name);
  $Email=MyText($Email);
  $Tema=MyText($Tema);
  $Msg=nl2br(MyText($Msg));
  $str='';
  
  
  if(strlen($Name)!=0 && strlen($Tema)!=0 && strlen($Email)!=0 && strlen($Msg)!=0)
  {
  	if(strlen($Name)>60 || strlen($Email)>70 || strlen($Tema)>100 || strlen($Msg)>300) $str='Error';
  	else 
  	{
		$to="dimakr85@tut.by";
		$title=$Tema;
		$headers="From: ".$Email."\r\nContent-type:text/html; charset=utf-8 \r\n";
		mail($to,$title,$Msg,$headers);
   	}
  }
header("Location: contacts.html");
?>