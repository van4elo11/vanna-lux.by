<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head><title>Реставрация ванн в Минске и Минской области. Эмалировка ванн, наливная ванна, акриловый вкладыш.</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<meta name='yandex-verification' content='5022f51f58fdd2c2' />
<meta name="description" content="Эмалировка ванн, наливная ванна,акриловый вкладыш. Профессиональная реставрация ванн в Минске и Минской области " />
<meta name="keywords" content="эмалировка ванн, наливная ванна, акриловый вкладыш, реставрация ванн,телефоны, покраска ванн, жидкий акрил, стакрил, контакты, восстановление ванн в минске и минской области" />
<meta name="Robots" content="index,follow" />
<link href="style_V.css" type="text/css" rel="stylesheet" />
<link href="favicon.ico" rel="shortcut icon" type="image/x-icon" />
</head><body>
<div id="wrapper">
<div id="header"><?php include "Incl/Header.php";?></div>
<div id="flashContent"><?php include "Incl/FlashContent.php";?></div>
<div id="polo_img"></div>
<div id="sidebar"><?php include "Incl/Menu.php";?></div>

<div id="content" style="height:700px;">
<h2>Контакты</h2><strong>По всем вопросам касающихся реставрации ванн можно Связаться с нами по телефонам:</strong>
<p>+375 29 305-45-02 (Velcom)</p><p>+375 29 562-92-52 (MTC)</p>
<p class="otstup"><strong>Контактное лицо:</strong> Дмитрий</p>
<p class="otstup"><strong>Работаем без выходных. Время работы: с 08.00-22.00</strong></p> 
<p style="margin-top:20px;font-size:14px;"><strong>Профессиональная реставрация ванн: эмалировка ванн, наливная ванна из жидкого акрила или стакрила, акриловый вкладыш в Минске, Дзержинске, Фаниполе, Солигорске, Слуцке, Копыле, Узде, Мяделе, Нарочи и многих других городах Минской области.</strong></p>
<p style="text-indent:20px; margin-top:40px;">Если у Вас возникли какие-либо вопросы или замечания, Вы можете связаться с нами путем заполнения формы приведенной ниже:</p>
<script type="text/javascript">
function splash(){if (document.myForm.username.value==''){alert("Укажите Ваше имя!");return false;}if (document.myForm.email.value==''){alert("Укажите Ваш email!");return false;}if (document.myForm.tema.value==''){alert("Укажите тему сообщения!"); return false;}if (document.myForm.msg.value==''){alert("Заполните текст сообщения!");return false;}return true;}
</script>
<form name="myForm" action="action.php" method="post" onSubmit="return splash();">
<fieldset><legend>Связаться с нами:</legend>
<table id="formTable">
<tr><td><label for="username">Ваше имя:</label></td><td><input name="username" id="username" value="" /></td></tr>
<tr><td><label for="email">Ваш email:</label></td><td><input name="email" id="email" value="" /></td></tr>
<tr><td><label for="tema">Тема сообщения:</label></td><td><input name="tema" id="tema" value=""/></td></tr>
<tr><td valign="top"><label for="msg">Сообщение:</label></td><td><textarea name="msg" id="msg" value=" "></textarea></td></tr>	
	
<!--
<tr><td valign="top"><label for="userfile">Прикрепить файл:</label></td><td><input type="file" name="userfile"></input></td></tr>	
-->	

<tr><td>&nbsp;</td><td><input type="submit" value="Отправить"/></td></tr>
</table></fieldset></form>
</div><?php include "Incl/EmalNalivTables.php";?><?php include "Incl/Footer.php";?></div></body></html>